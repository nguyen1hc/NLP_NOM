# student_114 — bản gộp để kiểm tra trên Kaggle

Đã gộp ba ảnh bạn tự làm và sáu ảnh được bổ sung vào cùng một bộ có 9 ảnh / 1940 box. Đây là bản nháp để kiểm tra, chưa xác nhận hoàn tất chất lượng gán nhãn để nộp.

| Ảnh | Box | Nguồn | Loại lưu trong tool |
|---|---:|---|---|
| 17077 | 276 | Hình học đã kiểm tra từ bản trước | Other: đồng thời nhãn dư và thiếu |
| 17390 | 238 | Bạn cung cấp, giữ nguyên toàn bộ annotation | Missing Content |
| 18591 | 172 | Bạn cung cấp, giữ nguyên toàn bộ annotation | Bình thường |
| 18592 | 237 | Bản nháp mới, ghi chú nhỏ cần kiểm tra kỹ | Missing Content: 45 MISS theo quy tắc bỏ ngoặc Hán Nôm |
| 31962 | 132 | Bạn cung cấp; sửa nhãn #91 theo PDF, giữ hình học và trạng thái | Extra Content |
| 46302 | 421 | Bản nháp mới | Other: đồng thời nhãn dư và thiếu |
| 46303 | 212 | Bản nháp mới | Extra Content: giữ dấu tròn trong nguồn, Excluded |
| 55431 | 197 | Bản nháp mới | Missing Content: ảnh có thêm chữ 祭 |
| 55432 | 55 | Bản nháp mới | Bình thường |

## Quy tắc nội dung theo yêu cầu mới nhất

- Nguyên văn Hán Nôm: chỉ xóa ngoặc `()[]{}（）［］｛｝〈〉《》`, không tự thêm/bớt chữ, không xóa dấu tròn `〇`, giữ các `□` đã có. Ngoại lệ theo yêu cầu rà font sau đó: sửa lỗi Unicode được xác minh theo PDF; chỉ đổi sang `@` khi đúng điều kiện.
- Phiên âm Hán Việt: đổi mỗi `[]` rỗng thành một `□` trước, rồi xóa ngoặc. Giữ nguyên chữ và thứ tự.
- Phần thuần Việt: được sửa theo PDF. Toát yếu dùng bản đã đối chiếu, không viết diễn giải mới.
- Các box, trạng thái và crop bạn cung cấp được giữ nguyên. Ngoại lệ nhãn được sửa theo yêu cầu rà lỗi font mới nhất: **31962, ô #91: 足 → 是**, đối chiếu PDF Tập 4, trang PDF 13 / trang in 526 và ảnh bia. `source_text`, nhãn ô #91, `text_sequence` và Content được cập nhật đồng bộ.
- Dùng `student_114.json` gốc trong Input. Các mục Content bổ sung và sửa lỗi Unicode chỉ lưu trong `.state/content.json`/annotation. Bộ nạp tạo mục còn thiếu trong bộ nhớ khi mở ảnh, không ghi vào nguồn và không dùng bản nguồn phụ.

## Rà lỗi font và quy tắc @

Đã kiểm tra bảy trang có phần Hán Nôm của chín ảnh, ảnh raster chèn trong các trang đó, các glyph nghi vấn và toàn bộ chuỗi font web đi kèm tool: NomNaTong, DengXian, PMingLiU, PMingLiU-ExtB; Arial cho ký tự ngoài CJK.

- Không phát hiện chữ bắt buộc đổi thành `@` trong các trang và font đã kiểm tra. Các trang phiên chép không có glyph dán bằng ảnh raster.
- `𦝧` ở 31962 không có trong NomNaTong/DengXian, nhưng có và hiển thị được qua PMingLiU-ExtB trong chuỗi font dự phòng của tool; giữ nguyên chữ này.
- Các chữ hiếm `𥸷`, `𣷷`, `𨕭`, `𡧲` có font hỗ trợ và được giữ nguyên. Không thay bằng `@` chỉ vì chữ hiếm.
- JSON ghi `足亦酬德報功`, còn PDF và ảnh bia đều là `是亦酬德報功`: xác định được chữ đúng nên sửa `是`, không dùng `@`.

Chi tiết ở `_review/font_audit/font_audit.json`; ảnh đối chiếu glyph ở `_review/font_audit/pdf_font_candidates.png`. Kiểm tra này xác minh PDF và font đi kèm; không xác nhận việc tải font trong trình duyệt Kaggle đang chạy của bạn.

## Những chỗ cần hiểu trước khi kiểm tra

**17077 và 46302:** tool gốc chỉ cho chọn một loại mismatch và không hỗ trợ đồng thời MISS và Excluded trong một ảnh. Hai ảnh này thực sự có cả hai, nên dùng Other với mô tả cụ thể. Other của tool chỉ lưu tọa độ, không giữ nhãn từng chữ, trạng thái hay crop trong giao diện gốc. Toàn bộ thông tin đó vẫn được cung cấp trong `review_details`, `character_review`, `review.html` và các ảnh xem trước. Đây là hạn chế chưa được giải quyết trong tool, không phải đã hoàn thành đầy đủ bước Status & Order cho hai ảnh đó.

- 17077: nguồn sau bỏ ngoặc có 279 ký tự; có 4 dấu tròn biên tập không khắc và ảnh có thêm 其 trong `以廣其傳云耳` (MISS #186). 279 - 4 + 1 = 276 vị trí.
- 46302: nguồn sau bỏ ngoặc có 422 ký tự; có dấu tròn và số chú thích 1 không khắc; thiếu nhãn 蓋 ở đầu `蓋聞`. 422 - 2 + 1 = 421 vị trí. Giữ nguyên tất cả chữ nguồn như bạn yêu cầu.

**18592:** nguồn gốc có 45 `[]` rỗng. Theo yêu cầu chỉ xóa ngoặc trong Hán Nôm và chỉ đổi `[]` sang `□` trong phiên âm, 45 chỗ trống này không còn nhãn Hán Nôm và được giữ vị trí bằng MISS. Vì vậy nguồn có 192 ký tự nhưng có 237 vị trí trên ảnh. Đây là hệ quả của quy tắc chuẩn hóa bạn chọn, khác với việc chuyên gia đã đọc được chữ mà JSON bỏ sót. Nhiều box ghi chú nhỏ bị hỏng được ước lượng vị trí và phải kiểm tra kỹ; xem `geometry_review: needs_close_review`.

**55431/55432:** giữ nguyên phần phiên âm theo nguồn, chỉ chuẩn hóa ngoặc. Nguồn phiên âm 55432 chứa cả phần tiếp nối của 55431, còn mặt 55431 không có mục phiên âm riêng (`null` trong bản xuất); không tự cắt/chuyển hay tạo phiên âm mới vì bạn yêu cầu không thêm bớt phiên âm. Toát yếu dùng nội dung dùng chung trong PDF.

Nhãn Intact/Damaged và mức hư hại của sáu ảnh mới là đánh giá sơ bộ từ ảnh, cần kiểm tra trước khi chốt. Expert Prediction dựa vào các chữ được PDF đặt trong ngoặc vuông theo Phàm Lệ. Không coi tất cả nhãn của PDF là Expert Prediction.

Không chạy mô hình phát hiện Kaggle. Box mới được tạo bằng xác định cột thủ công, phân đoạn khoảng cách chữ và thu gọn theo nét ảnh. OCR thử nghiệm không được dùng làm nguồn chữ chuẩn.

## Khôi phục lên Kaggle

1. Upload `student_114_kaggle_restore.zip` thành Dataset riêng, Add Input Dataset đó vào **notebook đang mở tool**. Gắn cả Dataset 9 ảnh và model như trước.
2. Mở `restore_in_kaggle.ipynb`, sao chép cell khôi phục vào chính notebook tool, sau các cell chuẩn bị dữ liệu và trước cell mở web. Cell tự tìm ZIP hoặc Dataset đã giải nén, kiểm tra checksum, khôi phục cả thư mục ẩn. Không chạy ở notebook khác vì chúng không dùng chung working.
3. Cell tạo ANNOTATION_DIR, SOURCE_JSON và APP_LAUNCHER:

```python
ANNOTATION_DIR = Path('/kaggle/working/annotations')
# SOURCE_JSON trỏ tới student_114.json gốc trong Input.
# APP_LAUNCHER do cell khôi phục tạo.
```

4. Trong command mở web, thay `str(REPO_DIR / 'gradio/app.py')` bằng `str(APP_LAUNCHER)`. Giữ `--output-dir` và `--source-json` dùng hai biến trên. SOURCE_JSON vẫn là file gốc trong Input; IMAGE_DIR vẫn là Dataset ảnh. Bản cập nhật annotation-sinonom.ipynb đã hỗ trợ APP_LAUNCHER.
5. Chạy cell mở web. History sẽ có đủ 9 file ảnh nếu IMAGE_DIR đúng. Khi mở lại, kiểm tra từng ảnh rồi Save Annotation; không bấm Run Detection để khôi phục.
6. Nếu output đã có dữ liệu khác, cell dừng để tránh ghi đè. Đổi tham số output trong lệnh khôi phục sang thư mục mới và dùng cùng đường dẫn cho app.

Tạo file trong `/kaggle/working` chỉ làm chúng xuất hiện trong Output của phiên hiện tại. Sau khi làm thêm, Save Annotation rồi Download All và giữ ZIP mới bên ngoài phiên. Gói khôi phục này không tự cập nhật khi bạn chỉnh trên Kaggle.

## Các gói

- `student_114_kaggle_restore.zip`: cấu trúc chạy lại tool, gồm các file từng ảnh, Content registry, bộ nạp dùng nguồn gốc và thông tin kiểm tra. Không chứa bản nguồn phụ.
- `annotations.zip`: đúng ba JSON xuất ra theo cấu trúc Download All.
- `student_114_submission_draft.zip`: ba JSON + `summary.pdf` tại gốc; vẫn là bản nháp, chưa nên nộp khi chưa xử lý các giới hạn nêu trên.
- `student_114_complete_review.zip`: toàn bộ các file kể trên cùng trang xem chín ảnh, contact sheet, báo cáo và script tạo dữ liệu.

`validation.json` ghi nhận kiểm tra schema, nạp lại ảnh bằng Workflow thật, kiểm tra giữ nguyên box/trạng thái/crop bạn gửi, chỉ sửa nhãn font đã xác minh và không thay chữ Hán Nôm/Hán Việt ngoài các quy tắc được phép. Những kiểm tra này không chứng minh mọi nhãn/hình học đều đúng về mặt nội dung.
