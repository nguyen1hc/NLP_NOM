"""Restore only user-owned images; preserve newer work and the original source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import zipfile


LAUNCHER_SOURCE = '"""Launch the upstream app while restoring saved Content from its output folder.\n\nOnly the selected record in memory is extended with sections already present in\nthe saved Content registry. The source JSON and upstream checkout stay unchanged.\n"""\nfrom copy import deepcopy\nfrom functools import wraps\nimport json\nimport os\nfrom pathlib import Path\nimport runpy\nimport sys\n\n\ndef enable_saved_content_sections(repo_dir):\n    gradio_dir = Path(repo_dir).resolve() / \'gradio\'\n    if str(gradio_dir) not in sys.path:\n        sys.path.insert(0, str(gradio_dir))\n    from annotation.workflow import Workflow\n    from annotation.text_extraction import validate_content_document\n\n    original = Workflow._saved_content_for\n    if getattr(original, \'_restores_missing_content_sections\', False):\n        return Workflow\n\n    @wraps(original)\n    def restore_content(self, image_name, code, source_record):\n        restored = deepcopy(original(self, image_name, code, source_record))\n        registry = self.output / \'.state\' / \'content.json\'\n        if not registry.exists():\n            return restored\n        documents = json.loads(registry.read_text(encoding=\'utf-8\'))\n        matches = [item for item in documents\n                   if isinstance(item, dict) and item.get(\'image\') == image_name]\n        if not matches:\n            return restored\n        # The upstream method has already checked uniqueness and schema.\n        saved = validate_content_document(matches[0], image_name)\n        faces = [face for face in restored.get(\'noi_dung\', [])\n                 if str(face.get(\'ky_hieu\')) == str(code)]\n        if not faces and str(code).isdigit():\n            faces = [face for face in restored.get(\'noi_dung\', [])\n                     if str(face.get(\'ky_hieu\')) == str(int(code))]\n        if len(faces) != 1:\n            raise ValueError(\'Exactly one face must match the restored Content.\')\n        face = faces[0]\n        sections = face.setdefault(\'chuyen_muc\', [])\n        existing = {section.get(\'tieu_de\') for section in sections}\n        for title in self.content_titles:\n            value = saved[\'content\'].get(title)\n            if title not in existing and isinstance(value, str):\n                sections.append({\'tieu_de\': title, \'van_ban\': value})\n                existing.add(title)\n        return restored\n\n    restore_content._restores_missing_content_sections = True\n    Workflow._saved_content_for = restore_content\n    return Workflow\n\n\ndef main():\n    repo = Path(os.environ.get(\'SINONOM_REPO_DIR\',\n                               \'/kaggle/working/SinoNom-Annotation\'))\n    app = repo / \'gradio/app.py\'\n    if not app.is_file():\n        raise FileNotFoundError(f\'Annotation app not found: {app}\')\n    enable_saved_content_sections(repo)\n    sys.argv[0] = str(app)\n    runpy.run_path(str(app), run_name=\'__main__\')\n\n\nif __name__ == \'__main__\':\n    main()\n'


KNOWN_ASSISTANT_DRAFTS = {'55432': ['1aedc885c22e3c013db6fed160dc47863f837316857f22024d5d9e82e5c47f43']}


def semantic_hash(document):
    return hashlib.sha256(json.dumps(document, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def native_documents(output):
    documents = {}
    for relative in ('', 'source_mismatches'):
        for path in (output / relative).glob('*.json'):
            if not path.stem.isdecimal():
                continue
            data = path.read_bytes()
            doc = json.loads(data)
            if Path(doc['image']).stem != path.stem:
                raise ValueError('Annotation filename/image mismatch: ' + str(path))
            if path.stem in documents:
                raise ValueError('Duplicate normal/mismatch annotation: ' + path.stem)
            documents[path.stem] = (path.relative_to(output).as_posix(), data, doc)
    return documents


def content_registry(output):
    path = output / '.state/content.json'
    values = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else []
    if not isinstance(values, list):
        raise ValueError('Content must be an array.')
    by_image = {}
    for record in values:
        if record['image'] in by_image:
            raise ValueError('Duplicate Content: ' + record['image'])
        by_image[record['image']] = record
    return by_image


def backup_my_work(output='/kaggle/working/annotations', archive=None):
    output = Path(output)
    archive = Path(archive) if archive else output.parent / 'my_annotations_backup.zip'
    docs, content = native_documents(output), content_registry(output)
    if not docs:
        raise ValueError('No saved annotations to back up.')
    payload, records = {}, []
    for stem, (relative, data, doc) in sorted(docs.items()):
        if doc['image'] not in content:
            raise ValueError('Missing saved Content for ' + doc['image'])
        payload[relative] = data
        records.append(content[doc['image']])
        meta = '.state/' + relative
        if (output / meta).is_file():
            payload[meta] = (output / meta).read_bytes()
    payload['.state/content.json'] = encode(records)
    payload['_support/launch_with_original_source.py'] = LAUNCHER_SOURCE.encode('utf-8')
    manifest = dict(version=1, images=[d['image'] for _, _, d in docs.values()],
                    total_boxes=sum(len(d['bounding_boxes']) for _, _, d in docs.values()),
                    original_source_unchanged=True,
                    ignore_known_assistant_drafts=KNOWN_ASSISTANT_DRAFTS,
                    files={name:dict(sha256=hashlib.sha256(data).hexdigest())
                           for name, data in payload.items()})
    archive.parent.mkdir(parents=True, exist_ok=True)
    pending = archive.with_suffix('.pending.zip')
    with zipfile.ZipFile(pending, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for name, data in payload.items():
            bundle.writestr('annotations/' + name, data)
        bundle.writestr('inscription_content.json', payload['.state/content.json'])
        bundle.writestr('user_work_manifest.json', encode(manifest))
        bundle.writestr('restore_my_work.py', Path(__file__).read_bytes())
    with zipfile.ZipFile(pending) as bundle:
        if bundle.testzip() is not None:
            raise ValueError('Backup ZIP failed verification.')
    pending.replace(archive)
    print('Backup:', archive, '| Images:', ', '.join(sorted(docs)))
    return archive


def restore_my_work(input_root, output='/kaggle/working/annotations'):
    root, output = Path(input_root), Path(output)
    manifest = json.loads((root / 'user_work_manifest.json').read_text(encoding='utf-8'))
    allowed = {Path(image).stem for image in manifest['images']}
    payload = {}
    for name, metadata in manifest['files'].items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or '\\' in name:
            raise ValueError('Unsafe backup path.')
        path = root / 'annotations' / name
        if name == '.state/content.json' and not path.is_file():
            path = root / 'inscription_content.json'
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != metadata['sha256']:
            raise ValueError('Backup checksum failed: ' + name)
        payload[name] = data
    fallback_content = {r['image']:r for r in json.loads(payload['.state/content.json'])}
    current_docs = native_documents(output) if output.is_dir() else {}
    current_content = content_registry(output) if output.is_dir() else {}
    excluded_drafts = manifest.get('ignore_known_assistant_drafts', {})
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
        stage = Path(temporary) / 'annotations'
        stage.mkdir()
        records = []
        for stem in sorted(allowed):
            use_current = stem in current_docs
            if use_current and semantic_hash(current_docs[stem][2]) in excluded_drafts.get(stem, []):
                use_current = False
                print('Replacing known assistant draft with original user work:', stem)
            if use_current:
                relative, data, doc = current_docs[stem]
                record = current_content.get(doc['image'])
                if record is None:
                    fallback_native = payload.get(relative)
                    if fallback_native is None or json.loads(fallback_native) != doc:
                        raise ValueError('Current annotation has no saved Content: ' + doc['image'])
                    record = fallback_content[doc['image']]
                meta = '.state/' + relative
                metadata = (output / meta).read_bytes() if (output / meta).is_file() else None
            else:
                matches = [name for name in payload
                           if not name.startswith('.state/') and Path(name).stem == stem]
                if len(matches) != 1:
                    raise ValueError('Backup must contain one annotation for ' + stem)
                relative = matches[0]
                data = payload[relative]
                doc = json.loads(data)
                record = fallback_content[doc['image']]
                meta = '.state/' + relative
                metadata = payload.get(meta)
            target = stage / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            records.append(record)
            if metadata is not None:
                target = stage / meta
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(metadata)
        registry = stage / '.state/content.json'
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_bytes(encode(records))
        support = stage / '_support/launch_with_original_source.py'
        support.parent.mkdir(parents=True, exist_ok=True)
        support.write_text(LAUNCHER_SOURCE, encoding='utf-8')
        expected = {p.relative_to(stage).as_posix():p.read_bytes()
                    for p in stage.rglob('*') if p.is_file()}
        actual = {p.relative_to(output).as_posix():p.read_bytes()
                  for p in output.rglob('*') if p.is_file()} if output.is_dir() else {}
        if actual != expected:
            previous = None
            if output.exists():
                timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
                previous = output.with_name('annotations_previous_' + timestamp)
                output.rename(previous)
            try:
                shutil.move(str(stage), str(output))
            except Exception:
                if previous is not None and not output.exists():
                    previous.rename(output)
                raise
            if previous is not None:
                print('Previous folder kept separately:', previous)
    print('Active saved images:', ', '.join(sorted(allowed)))
    backup_my_work(output)
    return output
