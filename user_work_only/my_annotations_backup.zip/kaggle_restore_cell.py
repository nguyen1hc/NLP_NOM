from pathlib import Path
import runpy

manifests = list(Path('/kaggle/input').rglob('user_work_manifest.json'))
if len(manifests) != 1:
    raise RuntimeError('Gắn đúng một Dataset chứa my_annotations_backup.zip.')
backup_root = manifests[0].parent
user_backup = runpy.run_path(str(backup_root / 'restore_my_work.py'))

if Path(SOURCE_JSON).name != 'student_114.json' or not Path(SOURCE_JSON).is_file():
    raise RuntimeError('Giữ SOURCE_JSON trỏ tới student_114.json gốc trong Input.')

ANNOTATION_DIR = user_backup['restore_my_work'](backup_root)
APP_LAUNCHER = ANNOTATION_DIR / '_support/launch_with_original_source.py'
backup_my_work = user_backup['backup_my_work']
