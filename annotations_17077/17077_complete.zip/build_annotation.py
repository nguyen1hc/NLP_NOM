"""Complete 17077 annotation coverage with explicit source mismatch provenance.

Geometry uses manually identified columns/reading order and image processing to
tighten per-glyph bounds. No Kaggle model, web session, or trained detector used.
Condition labels remain provisional visual estimates.
"""
import copy
import json
import re
import unicodedata
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter, gaussian_filter1d, label
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
SOURCE=ROOT/'student_114'
source_records=json.loads((ROOT/'content_review/student_114.normalized.draft.json').read_text())
record=next(r for r in source_records if '17077' in r['ky_hieu_vnchn'])
sections={s['tieu_de']:s['van_ban'] for s in record['noi_dung'][0]['chuyen_muc']}
source_text=sections['Nguyên văn chữ Hán Nôm']
im=Image.open(SOURCE/'17077.jpg').convert('RGB')
gray=np.asarray(im.convert('L'),dtype=np.float32)
fontroot=Path('/tmp/sinonom-inspect/fonts')
groups=[]

def regular(name,text,x,first=1405,pitch=158,halfwidth=88,halfheight=78,light=(),medium=()):
    chars=list(text) if isinstance(text,str) else list(text)
    groups.append(dict(name=name,chars=chars,coords=[
        [int(x-halfwidth),int(first+j*pitch-halfheight),int(x+halfwidth),int(first+j*pitch+halfheight)]
        for j in range(len(chars))],light=set(light),medium=set(medium)))
    if name.startswith('column_') and len(chars)==19:
        groups[-1]['coords'][-1][3]=4355
def explicit(name,text,coords,light=(),medium=()):
    assert len(text)==len(coords),(name,len(text),len(coords))
    groups.append(dict(name=name,chars=list(text),coords=coords,light=set(light),medium=set(medium)))

explicit('title','后碑誌',[[2530,800,2815,1095],[1840,805,2135,1100],[1140,805,1455,1120]],light=[1,2,3])
regular('column_01','河城第三户香義村為立碑誌事盖聞',3000,
    light=[3,4,5,8,9,13,14,15],medium=[3,8])
regular('column_02','孝者人之本善者人之根敬其所尊爱其所親古',2831,
    light=[1,2,5,8,11,12,13,14,15,17,18,19],medium=[13,18,19])
regular('column_03','今同一揆也兹因有河東省懷德府慈廉縣雲耕',2693,
    light=[3,4,6,9,11,12,13,14,15,16,17,18,19],medium=[17,19])
regular('column_04','縂雲耕社金黄村人陳氏富適見民村亭宇重新',2554,
    light=[1,2,3,4,7,10,11,12,13,14,15,16,17,18,19],medium=[18,19])
regular('column_05','规模再造風淳俗美祀事風光為此情願出銀一',2396,
    light=[2,3,4,5,6,7,9,10,11,12,14,15,16,17,18,19],medium=[19])
groups[-1]['coords'][-2]=[2325,4020,2475,4175]
groups[-1]['coords'][-1]=[2325,4180,2490,4335]
regular('column_06','百伍十元以助民力以廣民财仍請寄后者三',2234,
    light=[1,2,3,4,6,9,11,12,13,14,15,16,17,18],medium=[18])
groups[-1]['coords'][-1]=[2155,4010,2290,4130]
explicit('small_note_A','由考妣舆本身',[
    [2270,4110,2370,4200],[2270,4200,2370,4280],[2270,4280,2370,4350],
    [2170,4110,2260,4200],[2170,4200,2260,4280],[2170,4280,2260,4350]],
    light=[1,2,3,4,5,6],medium=[3,6])
regular('column_07','以傳不朽民村商同妥順玉成其事凡至忌日炤',2094,
    light=[1,4,5,6,9,10,11,12,13,14,15,16,17,18,19],medium=[19])
regular('column_08','禮而行與春秋從祀配饗人有心也精誠必達于',1946,
    light=[1,2,3,4,8,9,11,12,13,15,16,17,18,19],medium=[19])
regular('column_09','鬼神德能忘乎名姓宜垂於永久其贵位號舆忌',1778,
    light=[2,4,6,7,8,9,10,12,14,15,16,17,18,19],medium=[19])
# The image has 其 between 廣 and 傳, absent from the source PDF/JSON.
regular('column_10',list('日並禮品詳誌于石以廣')+['MISS']+list('傳云耳'),1637,
    light=[3,5,6,8,9,10,12,13,14])
regular('father_name','顯考陳贵公諱德歸字福慎府君',1487,first=1225,
    light=[1,2,3,4,5,6,7,8,9,10,12])
explicit('father_memorial_date','十月三十日忌',[
    [1460,y-45,1570,y+45] for y in [3260,3365,3465,3560,3655,3760]],
    light=[1,2,3,4,5,6],medium=[6])
regular('mother_name','顯妣陳公正室阮贵氏諱汝號妙清孺人',1333,first=1250,pitch=158,
    light=[1,2,3,4,6,7,8,9,10,11,12,13,14,15,16])
groups[-1]['coords'][-2]=[1245,3370,1430,3510]
groups[-1]['coords'][-1]=[1245,3505,1430,3620]
explicit('mother_memorial_date','四月二十六日忌',[
    [1310,y-48,1455,y+48] for y in [3688,3775,3850,3945,4033,4118,4200]],
    light=[1,2,3,4,5,6,7],medium=[7])
regular('benefactor_name','陳氏富號妙贵',1175,first=1225,light=[1,2,4,6])
explicit('benefactor_date_blank','月日忌',[
    [1100,3655,1260,3790],[1100,3950,1260,4100],[1100,4115,1260,4290]],light=[1,2,3])
regular('offerings','忌日禮用翰歆粢盛金銀芙酒具足',1019,
    light=[3,5,6,7,8,9,10,11,12,13,14])
explicit('small_note_B','三忌亦周由每忌準銀二元',[
    [1025,y-55,1130,y+55] for y in [3585,3680,3780,3880]]+[
    [915,y-48,1030,y+48] for y in [3570,3670,3765,3860,3970,4065,4160]],
    light=list(range(1,12)))
regular('date_inscription','保大七年歲在壬申吉日立',875,first=1275,
    light=[1,4,5,6,7,8,9,10,11],medium=[4,6,10])

def countable(text):
    return ''.join(c for c in unicodedata.normalize('NFC',text)
        if not c.isspace() and not unicodedata.category(c).startswith('P'))
sequence=[c for g in groups for c in g['chars']]
assert len(sequence)==276 and sequence.count('MISS')==1
assert ''.join(c for c in sequence if c!='MISS')==countable(source_text)

def tighten(bbox):
    """Tighten within a manually delimited cell; never infer character identity."""
    x1,y1,x2,y2=bbox
    patch=gray[y1:y2,x1:x2]
    ink=(patch>155)&(patch-gaussian_filter(patch,7)>17)
    labs,n=label(ink)
    sizes=np.bincount(labs.ravel());keep=sizes>=10;keep[0]=False
    ink=keep[labs]
    yy,xx=np.where(ink)
    if len(xx)<40:return bbox
    # Keep a margin so small detached strokes are not clipped.
    return [max(x1,x1+int(xx.min())-5),max(y1,y1+int(yy.min())-5),
            min(x2,x1+int(xx.max())+6),min(y2,y1+int(yy.max())+6)]

variants={'户':'戶','盖':'蓋','爱':'愛','兹':'茲','縂':'總','黄':'黃','规':'規','财':'財','舆':'與','贵':'貴'}
rows=[];source_index=0
for group in groups:
    for j,(char,cell) in enumerate(zip(group['chars'],group['coords']),1):
        level=2 if j in group['medium'] else 1 if j in group['light'] else None
        observed='其' if char=='MISS' else variants.get(char,char)
        if group['name']=='column_05' and j==19:observed='壹'
        if group['name']=='column_06' and j in [1,3]:observed={1:'佰',3:'拾'}[j]
        if group['name']=='small_note_B' and j==5:observed='扣'
        suspicious=char!='MISS' and observed!=char
        rows.append(dict(id=len(rows)+1,source_index=None if char=='MISS' else source_index,
            label=char,observed_candidate=observed,group=group['name'],group_index=j,
            bbox=tighten(cell),status='damaged' if level else 'intact',damage_level=level,
            unknown=False,unavailable_font=False,expert_prediction=False,suspicious=suspicious,
            condition_review='provisional_visual_estimate'))
        if char!='MISS':source_index+=1
assert source_index==275

boxes={str(r['id']):{**{k:r[k] for k in ['bbox','status','damage_level','unknown',
    'unavailable_font','expert_prediction','suspicious']},'order':r['id']} for r in rows}
miss_id=next(r['id'] for r in rows if r['label']=='MISS')
assert miss_id==186
geometry=dict(image_resize=dict(source_size=[3840,5474],output_size=[3840,5474],scale_x=1.0,scale_y=1.0),
    crop=dict(top_left=[775,760],top_right=[3125,760],bottom_right=[3125,4370],bottom_left=[775,4370]))
doc=dict(image='17077.jpg',inscription_code='17077',source_text=source_text,
    source_character_count=275,bounding_box_count=276,issue_type=['missing_text'],
    note='Ảnh có chữ 其 ở ID 186: 以廣其傳云耳. PDF Tập 4, trang PDF 10 (trang in 408) và JSON chỉ có 以廣傳云耳. Giữ nội dung theo PDF, gán MISS cho khung 186 theo quy tắc Missing Content. Chữ quan sát được 其 được ghi riêng trong character_review.json. Các mức hư hại là đánh giá sơ bộ, cần rà soát.',
    bounding_boxes=boxes,annotations={str(r['id']):r['label'] for r in rows},**geometry)
content=dict(image='17077.jpg',inscription_code='17077',content={
    'Tên bia':record['ten_bia'],'Địa điểm':record['dia_diem'],'Niên đại':record['nien_dai'],
    **sections})
def write(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
write('text_annotations.json',[])
write('source_mismatches.json',[doc])
write('inscription_content.json',[content])
write('character_review.json',rows)
write('source_17077.normalized.json',[record])
write('source_17077.original.json',[next(a for a in json.loads((SOURCE/'student_114.json').read_text()) if '17077' in a['ky_hieu_vnchn'])])
write('coverage.json',dict(image='17077.jpg',positions=276,source_characters=275,missing_source_character=dict(box_id=186,observed='其',export_label='MISS'),
    method='Manual column identification and image processing to tighten per-character boxes. No trained detection model used.',
    all_condition_labels_provisional=True,normalization='Removed four editorial 〇 and four fullwidth parentheses from alignment text. Original source retained.',
    groups=[dict(name=g['name'],count=len(g['chars'])) for g in groups]))

font=ImageFont.truetype(str(fontroot/'Arial.ttf'),24)
def overlay():
    out=im.copy();d=ImageDraw.Draw(out)
    for row in rows:
        color='#ffca28' if row['label']=='MISS' else '#b165ff' if row['suspicious'] else '#ff5656' if row['status']=='damaged' else '#2cdb91'
        d.rectangle(row['bbox'],outline=color,width=4)
        x,y,_,_=row['bbox'];s=str(row['id']);d.rectangle((x,y,x+len(s)*15+6,y+29),fill='#14253c')
        d.text((x+3,y),s,font=font,fill='white')
    d.rectangle((775,760,3125,4370),outline='#29c4eb',width=5)
    return out
preview=overlay();preview.save(OUT/'17077_annotated.jpg',quality=94)
small=preview.copy();small.thumbnail((1600,2000));small.save(OUT/'17077_overview.jpg',quality=92)
im.crop((775,760,3125,4370)).save(OUT/'17077_crop_preview.jpg',quality=94)
# Proof of the true extra image glyph, not merely a count-based inference.
im.crop((1535,2660,1735,3540)).save(OUT/'missing_source_qi.jpg',quality=96)

W,H=150,180;han=ImageFont.truetype(str(fontroot/'MicrosoftYahei.ttf'),26)
latin=ImageFont.truetype(str(fontroot/'Arial.ttf'),18)
for page,start in enumerate(range(0,len(rows),100),1):
    selected=rows[start:start+100];sheet=Image.new('RGB',(W*10,H*10),'#f6f8fc');d=ImageDraw.Draw(sheet)
    for k,r in enumerate(selected):
        x=(k%10)*W;y=(k//10)*H
        piece=im.crop(r['bbox']);piece.thumbnail((130,113));sheet.paste(piece,(x+(W-piece.width)//2,y+27))
        d.text((x+7,y+3),f"#{r['id']}",font=latin,fill='#14253c')
        labeltext=r['label'];d.text((x+7,y+143),labeltext,font=latin if labeltext=='MISS' else han,fill='#14253c')
        d.text((x+64,y+150),'D'+str(r['damage_level']) if r['damage_level'] else 'intact?',font=latin,fill='#7c3434')
    sheet.save(OUT/f'characters_{page:02d}.jpg',quality=94)
print('Built 276 positions, 275 PDF labels, one MISS at box 186; all condition labels provisional.')
